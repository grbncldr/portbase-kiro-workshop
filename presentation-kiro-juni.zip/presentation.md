---
marp: true
theme: default
paginate: true
style: |
  section {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    padding-top: 80px;
    background: #F2F3F3;
    color: #16191F;
  }
  section::before {
    content: '';
    position: absolute;
    top: 20px;
    left: 30px;
    width: 120px;
    height: 50px;
    background-image: url('logo.png');
    background-size: contain;
    background-repeat: no-repeat;
    filter: brightness(0) saturate(100%);
  }
  h1 {
    color: #232F3E;
    border-bottom: 3px solid #FF9900;
    padding-bottom: 0.3em;
  }
  h2 {
    color: #232F3E;
  }
  h3 {
    color: #545B64;
  }
  a {
    color: #0073BB;
  }
  code {
    background: #f4f4f4;
    color: #232F3E;
    padding: 0.2rem 0.4rem;
    border-radius: 3px;
  }
  pre {
    background: #1e1e1e;
    color: #d4d4d4;
    border-radius: 6px;
  }
  pre code {
    background: none;
    color: inherit;
  }
  table {
    font-size: 0.5em;
    width: 100%;
    border-collapse: collapse;
  }
  th {
    background: #232F3E;
    color: white;
    padding: 12px 16px;
    text-align: left;
  }
  td {
    background: white;
    padding: 10px 16px;
    border-bottom: 1px solid #D5DBDB;
  }
  tr:nth-child(even) td {
    background: #F2F3F3;
  }
  blockquote {
    border-left: 4px solid #FF9900;
    background: #FEF3E8;
    padding: 1rem;
    color: #8B4513;
  }
  strong {
    color: #232F3E;
  }
  section.lead {
    background: linear-gradient(135deg, #232F3E 0%, #37475A 100%) !important;
    color: white !important;
  }
  section.lead h1 {
    color: white !important;
    border-bottom-color: #FF9900 !important;
  }
  section.lead h2 {
    color: #FF9900 !important;
  }
  section.lead::before {
    filter: none !important;
  }
---

<!-- _class: lead -->
<style scoped>
section { display: flex; flex-direction: column; align-items: center; justify-content: center; }
h1 { border-bottom: none !important; font-size: 2.2em; }
h2 { margin-top: 20px; }
.meta { margin-top: 40px; font-size: 0.6em; opacity: 0.8; }
</style>

# Kiro Workshop

---

# Agenda

<style scoped>
.agenda { display: flex; flex-direction: column; gap: 5px; margin: 10px auto 0; max-width: 400px; }
.agenda-item { display: flex; align-items: center; gap: 10px; background: white; padding: 6px 12px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-left: 3px solid #FF9900; }
.agenda-num { font-size: 0.8em; font-weight: bold; color: #FF9900; min-width: 20px; }
.agenda-text { font-size: 0.55em; color: #232F3E; }
</style>

<div class="agenda">
<div class="agenda-item"><span class="agenda-num">1</span><span class="agenda-text">Introduction</span></div>
<div class="agenda-item"><span class="agenda-num">2</span><span class="agenda-text">Open Discussion</span></div>
<div class="agenda-item"><span class="agenda-num">3</span><span class="agenda-text">Developer Responsibilities</span></div>
<div class="agenda-item"><span class="agenda-num">4</span><span class="agenda-text">Kiro Concepts</span></div>
<div class="agenda-item"><span class="agenda-num">5</span><span class="agenda-text">Lunch</span></div>
<div class="agenda-item"><span class="agenda-num">6</span><span class="agenda-text">Guided Workshop</span></div>
<div class="agenda-item"><span class="agenda-num">7</span><span class="agenda-text">Q&A</span></div>
<div class="agenda-item"><span class="agenda-num">8</span><span class="agenda-text">Evaluation</span></div>
</div>

---

<style scoped>
section { display: flex; flex-direction: column; align-items: center; justify-content: center; }
h1 { border-bottom: none !important; font-size: 1.4em; text-align: center; line-height: 1.4; color: #232F3E; }
.lead-in { font-size: 1em; text-align: center; color: #545B64; margin-bottom: 20px; }
.subtitle { font-size: 0.9em; text-align: center; color: #545B64; margin-top: 20px; }
</style>

<p class="lead-in">Using AI Tools brings ....</p>

# Challenges, Concerns and Responsibilities

<p class="subtitle">What do you see, feel and experience on this?</p>

---

# Developer Responsibilities with AI Tools

<style scoped>
.intro { font-size: 0.6em; color: #545B64; margin-bottom: 15px; }
.responsibilities { display: flex; gap: 12px; margin-top: 15px; }
.resp { flex: 1; background: white; padding: 15px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-left: 4px solid #FF9900; }
.resp h3 { margin: 0 0 8px 0; font-size: 0.65em; color: #232F3E; }
.resp p { margin: 0; font-size: 0.48em; color: #545B64; line-height: 1.5; }
.policy { margin-top: 20px; background: #FEF3E8; padding: 15px; border-radius: 8px; border-left: 4px solid #FF9900; }
.policy p { margin: 0; font-size: 0.55em; }
.discussion { margin-top: 15px; font-size: 0.75em; color: #232F3E; font-style: italic; text-align: center; }
</style>

<p class="intro">Before we dive into Kiro, let's discuss our responsibilities as developers using AI-powered tools.</p>

<div class="responsibilities">
<div class="resp">
<h3>Code Ownership</h3>
<p>You are responsible for all code, AI-generated or not. Review, understand, and validate before committing.</p>
</div>
<div class="resp">
<h3>Data Privacy</h3>
<p>Never share sensitive data, credentials, or customer information with AI tools.</p>
</div>
<div class="resp">
<h3>Security Review</h3>
<p>AI can introduce vulnerabilities. Always apply security best practices and code review standards.</p>
</div>
<div class="resp">
<h3>Compliance</h3>
<p>Ensure AI-assisted work complies with Portbase AI policies and applicable regulations.</p>
</div>
</div>

<div class="policy">
<p><strong>Portbase AI Policy:</strong> Refer to the internal AI usage guidelines for approved tools, data handling requirements, and compliance obligations.</p>
</div>

---

# The Limits of Vibe Coding

<style scoped>
.compare { display: flex; gap: 20px; margin-top: 20px; }
.col { flex: 1; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.col h3 { margin: 0 0 15px 0; font-size: 0.85em; }
.col ul { margin: 0; padding-left: 20px; font-size: 0.55em; line-height: 1.6; }
.works { border-top: 4px solid #1D8102; }
.breaks { border-top: 4px solid #D13212; }
blockquote { margin-top: 20px; font-size: 0.55em; }
</style>

<div class="compare">
<div class="col works">
<h3>Works for Prototypes</h3>
<ul>
<li>Quick iterations on ideas</li>
<li>Small scripts and utilities</li>
<li>Exploring new technologies</li>
<li>Learning new concepts</li>
</ul>
</div>
<div class="col breaks">
<h3>Breaks at Scale</h3>
<ul>
<li><strong>Security vulnerabilities</strong>: 40-62% of AI-generated code contains security flaws</li>
<li><strong>Technical debt</strong>: Fast to build, expensive to maintain</li>
<li><strong>Debugging nightmare</strong>: More time debugging AI code than writing it yourself</li>
</ul>
</div>
</div>

---

<!-- _class: lead -->
<style scoped>
section { display: flex; flex-direction: column; align-items: center; justify-content: center; }
h1 { border-bottom: none !important; font-size: 2.2em; }
</style>

# Enter Kiro

---

# What is Kiro?

<style scoped>
.definition { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-left: 4px solid #FF9900; margin: 15px 0; }
.definition p { margin: 0; font-size: 0.75em; line-height: 1.6; }
.features { display: flex; gap: 12px; margin-top: 20px; }
.feature { flex: 1; background: white; padding: 15px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center; border-top: 3px solid #FF9900; }
.feature h3 { margin: 0 0 8px 0; font-size: 0.7em; }
.feature p { margin: 0; font-size: 0.48em; color: #545B64; }
</style>

<div class="definition">
<p>An <strong>agentic, AI-powered IDE</strong> that helps developers move from a single prompt to fully specified features, including requirements, design, tasks, tests, and documentation.</p>
</div>

<div class="features">
<div class="feature">
<h3>VS Code Foundation</h3>
<p>Familiar interface, all your extensions work</p>
</div>
<div class="feature">
<h3>Spec-Driven Workflow</h3>
<p>Requirements before code</p>
</div>
<div class="feature">
<h3>Agentic Execution</h3>
<p>Kiro autonomously explores, plans, and codes</p>
</div>
<div class="feature">
<h3>Full Traceability</h3>
<p>Decisions captured in spec files</p>
</div>
</div>

---

# Claude Models in Kiro

<style scoped>
.models { display: flex; justify-content: center; margin-top: 20px; }
table { font-size: 0.6em; }
th { background: #232F3E; color: white; padding: 12px 20px; }
td { background: white; padding: 10px 20px; }
</style>

<div class="models">

| Model | Use Case |
|-------|----------|
| **Auto** | Let Kiro choose the right model |
| Opus 4.8 | Deep reasoning, complex problem solving |
| Opus 4.6 / 4.7 | Best agentic coding, hard bugs |
| Opus 4.5 | Architecture, planning |
| Sonnet 4.5 / 4.6 | Feature implementation, debugging |
| Haiku 4.5 | Quick fixes, fast and cheap |

</div>

<p style="text-align: center; font-size: 0.55em; margin-top: 20px;">📖 <a href="https://kiro.dev/docs/models/">https://kiro.dev/docs/models/</a></p>

---

# Core Concept: Spec-Driven Development

<style scoped>
.shift { display: flex; gap: 30px; margin: 30px 0; align-items: center; justify-content: center; }
.old, .new { background: white; padding: 25px 35px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center; }
.old { border-top: 4px solid #D13212; }
.new { border-top: 4px solid #1D8102; }
.old h3, .new h3 { margin: 0 0 10px 0; font-size: 0.8em; }
.old p, .new p { margin: 0; font-size: 0.55em; color: #545B64; }
.arrow { font-size: 2em; color: #FF9900; }
.bottom { text-align: center; margin-top: 25px; }
.bottom p { font-size: 0.65em; }
</style>

<div class="shift">
<div class="old">
<h3>Vibe Coding</h3>
<p>"Write the code for me"</p>
</div>
<div class="arrow">→</div>
<div class="new">
<h3>Spec-Driven Development</h3>
<p>"Write the spec, not the code"</p>
</div>
</div>

<div class="bottom">

**The mental shift:** Define behavior, constraints, and acceptance criteria first. Then let the agent implement against that contract.

You specify **WHAT** you want. Kiro figures out **HOW**.

</div>

---

# The 3-Phase Workflow

<style scoped>
.phases { display: flex; gap: 15px; margin-top: 20px; }
.phase { flex: 1; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 4px solid #FF9900; }
.phase h2 { margin: 0 0 10px 0; font-size: 0.85em; color: #232F3E; }
.phase h3 { margin: 0 0 8px 0; font-size: 0.6em; color: #FF9900; }
.phase p { margin: 0; font-size: 0.5em; line-height: 1.5; color: #545B64; }
.diagram { text-align: center; margin-top: 25px; font-size: 0.55em; }
</style>

<div class="phases">
<div class="phase">
<h2>requirements.md</h2>
<h3>WHAT to build</h3>
<p>User stories with acceptance criteria, edge cases, and EARS notation for testable requirements</p>
</div>
<div class="phase">
<h2>design.md</h2>
<h3>HOW to build it</h3>
<p>Technical architecture, sequence diagrams, data models, and API contracts</p>
</div>
<div class="phase">
<h2>tasks.md</h2>
<h3>DO the implementation</h3>
<p>Detailed implementation plan with ordered tasks, dependencies, and progress tracking</p>
</div>
</div>

<div class="diagram">

**Prompt** → `requirements.md` → `design.md` → `tasks.md` → **Working Code**

</div>

---

# Phase 1: Requirements

<style scoped>
pre { font-size: 0.55em; }
.note { font-size: 0.5em; margin-top: 15px; color: #545B64; }
</style>

Instead of jumping straight to code, Kiro creates **well-defined requirements** from your prompt:

```markdown
## User Story: Note Creation

As a user, I want to create notes with a title and content
so that I can capture and organize my thoughts.

### Acceptance Criteria (EARS Notation)

WHEN the user clicks the "New Note" button
THE SYSTEM SHALL display a form with title and content fields

WHEN the user submits a valid note (title required, content optional)
THE SYSTEM SHALL save the note and display it in the notes list

IF the user submits without a title
THEN THE SYSTEM SHALL display a validation error and prevent submission

WHILE the note is being saved
THE SYSTEM SHALL display a loading indicator
```

<p class="note"><strong><a href="https://en.wikipedia.org/wiki/Easy_Approach_to_Requirements_Syntax">EARS Notation</a></strong> (Easy Approach to Requirements Syntax) ensures every requirement maps directly to a test case. No ambiguity.</p>

---

# Phase 2: Design

<style scoped>
.subtitle { font-size: 0.55em; color: #545B64; margin-top: -5px; }
.design-grid { display: flex; gap: 15px; margin-top: 15px; }
.design-card { flex: 1; background: white; padding: 12px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 3px solid #FF9900; }
.design-card h3 { margin: 0 0 8px 0; font-size: 0.6em; color: #232F3E; }
.design-card p, .design-card code { font-size: 0.45em; color: #545B64; line-height: 1.5; }
.design-card pre { background: #f4f4f4; padding: 8px; border-radius: 4px; font-size: 0.42em; margin: 5px 0; color: #232F3E; }
.arch-flow { display: flex; align-items: center; justify-content: center; gap: 10px; font-size: 0.5em; margin: 8px 0; }
.arch-box { background: #232F3E; color: white; padding: 8px 12px; border-radius: 4px; text-align: center; }
.arch-arrow { color: #FF9900; font-weight: bold; }
</style>

<p class="subtitle">Architecture decisions, data models, and API contracts</p>

<div class="design-grid">
<div class="design-card">
<h3>Architecture</h3>
<div class="arch-flow">
<div class="arch-box">React<br/>Frontend</div>
<span class="arch-arrow">→</span>
<div class="arch-box">Express<br/>API</div>
<span class="arch-arrow">→</span>
<div class="arch-box">PostgreSQL<br/>Database</div>
</div>
</div>
<div class="design-card">
<h3>Data Model</h3>
<pre>Note {
  id: UUID
  title: string (required)
  content: text (optional)
  createdAt: timestamp
  updatedAt: timestamp
}</pre>
</div>
<div class="design-card">
<h3>API Endpoints</h3>
<pre>POST   /api/notes     → Create
GET    /api/notes     → List all
PUT    /api/notes/:id → Update
DELETE /api/notes/:id → Delete</pre>
</div>
</div>

---

# Phase 3: Tasks & Implementation

<style scoped>
pre { font-size: 0.52em; }
.note { font-size: 0.55em; margin-top: 15px; background: white; padding: 15px; border-radius: 8px; border-left: 4px solid #FF9900; }
</style>

Kiro generates tasks **correctly ordered based on dependencies**, including tests:

```markdown
## Implementation Tasks

### Phase 1: Data Layer
- [x] 1. Create Note TypeScript interface and Zod schema
- [x] 2. Set up Prisma schema with Note model
- [x] 3. Create database migration

### Phase 2: API Layer
- [ ] 4. Implement POST /api/notes endpoint
- [ ] 5. Implement GET /api/notes endpoint
- [ ] 6. Add input validation middleware
      _Requirements: AC-3_

### Phase 3: Frontend
- [ ] 7. Create NoteForm component with validation
- [ ] 8. Create NoteList component
- [ ] 9. Add loading states and error handling
      _Requirements: AC-4_

### Phase 4: Testing
- [ ] 10. Unit tests for API endpoints
- [ ] 11. Integration tests for note CRUD flow
```

<div class="note">
<strong>Click a task → Kiro implements it with full context</strong> from requirements and design.
</div>

---

# Steering Files

<style scoped>
.files { display: flex; gap: 15px; margin-top: 15px; }
.file { flex: 1; background: white; padding: 15px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 4px solid #FF9900; }
.file h2 { margin: 0 0 8px 0; font-size: 0.75em; color: #232F3E; }
.file h3 { margin: 0 0 8px 0; font-size: 0.55em; color: #FF9900; }
.file p { margin: 0; font-size: 0.48em; color: #545B64; line-height: 1.4; }
.result { margin-top: 20px; text-align: center; font-size: 0.6em; color: #FF9900; font-weight: bold; }
</style>

Steering docs establish **core project context** loaded into every conversation:

<div class="files">
<div class="file">
<h2>product.md</h2>
<h3>PURPOSE + USERS</h3>
<p>What the product is, who it's for, core features</p>
</div>
<div class="file">
<h2>tech.md</h2>
<h3>FRAMEWORKS + CONSTRAINTS</h3>
<p>Tech stack, coding standards, security requirements, patterns to follow</p>
</div>
<div class="file">
<h2>structure.md</h2>
<h3>FILE ORGANIZATION</h3>
<p>Directory layout, naming conventions, where to put new files</p>
</div>
</div>

<p class="result">https://kiro.dev/docs/steering/</p>

---

# Java Steering Example

<style scoped>
pre { font-size: 0.55em; }
.note { margin-top: 15px; font-size: 0.55em; color: #545B64; text-align: center; }
</style>

```markdown
# tech.md - Java/Spring Standards

## Framework
- Java 21, Spring Boot 3.x, Constructor injection ONLY

## Architecture
- Interface + Impl pattern, Package: com.portbase.{domain}.{layer}

## Conventions
- SLF4J with @Slf4j, Custom exceptions extend BaseException
- DTOs separate from entities (MapStruct), @Valid for validation
```

---

# Before and After: Java Code Generation

<style scoped>
.compare { display: flex; gap: 15px; margin-top: 10px; }
.before, .after { flex: 1; background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.1); padding: 12px; border-radius: 8px; }
.before { border-top: 4px solid #D13212; }
.after { border-top: 4px solid #1D8102; }
.before h3, .after h3 { margin: 0 0 8px 0; font-size: 0.75em; }
.before pre, .after pre { font-size: 0.45em; margin: 0; }
</style>

<div class="compare">
<div class="before">
<h3>❌ Without Steering</h3>

```java
@Service
public class OrderService {
    @Autowired
    private OrderRepository orderRepo;

    public Order create(Order order) {
        System.out.println("Creating");
        return orderRepo.save(order);
    }
}
```

</div>
<div class="after">
<h3>✅ With Steering</h3>

```java
@Service @Slf4j
public class OrderServiceImpl
    implements OrderService {
    private final OrderRepository orderRepo;

    public OrderServiceImpl(OrderRepository r) {
        this.orderRepo = r;
    }

    public Order create(CreateOrderRequest req) {
        log.info("Creating: {}", req.getId());
        return orderRepo.save(mapper.toEntity(req));
    }
}
```

</div>
</div>

---

# Agent Hooks

<style scoped>
.flow { display: flex; align-items: center; justify-content: center; gap: 10px; margin: 25px 0; font-size: 0.55em; }
.step { background: white; padding: 12px 18px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.arrow { color: #FF9900; font-size: 1.3em; }
.examples { display: flex; gap: 10px; margin-top: 20px; flex-wrap: wrap; justify-content: center; }
.example { width: 30%; background: white; padding: 12px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-left: 3px solid #FF9900; }
.example h3 { margin: 0 0 5px 0; font-size: 0.55em; color: #232F3E; }
.example p { margin: 0; font-size: 0.45em; color: #545B64; }
</style>

Event-driven automations that trigger on file changes or manual actions:

<div class="flow">
<div class="step">Save file</div>
<div class="arrow">→</div>
<div class="step">Hook triggers</div>
<div class="arrow">→</div>
<div class="step">Agent runs</div>
<div class="arrow">→</div>
<div class="step">Tests generated</div>
</div>

<div class="examples">
<div class="example">
<h3>Auto-Generate Tests</h3>
<p>Handler saved → Unit tests created</p>
</div>
<div class="example">
<h3>Update Documentation</h3>
<p>API changed → OpenAPI spec updated</p>
</div>
<div class="example">
<h3>Lint on Save</h3>
<p>Any file → Format and validate</p>
</div>
</div>

---

# MCP Servers

<style scoped>
.intro { font-size: 0.6em; color: #545B64; margin-bottom: 15px; }
.flow { text-align: center; font-size: 0.7em; background: white; padding: 15px; border-radius: 8px; margin-bottom: 15px; }
.grid { display: flex; flex-wrap: wrap; gap: 12px; justify-content: center; }
.card { width: 28%; background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.1); padding: 12px; border-radius: 8px; border-left: 3px solid #FF9900; }
.card h3 { margin: 0 0 6px 0; font-size: 0.6em; color: #232F3E; }
.card p { margin: 0; font-size: 0.48em; color: #545B64; }
</style>

<p class="intro"><strong>Model Context Protocol</strong> connects Kiro to external tools and data sources.</p>

<div class="flow">Kiro ◀──▶ MCP Server ◀──▶ External APIs & Docs</div>

<div class="grid">
<div class="card"><h3>AWS</h3><p>Search AWS documentation</p></div>
<div class="card"><h3>Context7</h3><p>TypeScript, CDK best practices</p></div>
<div class="card"><h3>GitHub</h3><p>Access repos, issues, PRs</p></div>
<div class="card"><h3>PostgreSQL</h3><p>Query database schemas</p></div>
<div class="card"><h3>Java</h3><p>Maven, Spring Boot patterns</p></div>
</div>

---

# Powers

<style scoped>
.intro { font-size: 0.6em; color: #545B64; margin-bottom: 20px; }
.powers { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; }
.power { width: 18%; background: white; padding: 12px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center; border-top: 3px solid #FF9900; }
.power h3 { margin: 0 0 5px 0; font-size: 0.6em; color: #232F3E; }
.power p { margin: 0; font-size: 0.42em; color: #545B64; }
.note { margin-top: 20px; font-size: 0.55em; text-align: center; }
</style>

<p class="intro"><strong>Curated packages from AWS and partners</strong> that bundle MCP servers, steering files, and hooks for specific tools and platforms.</p>

<div class="powers">
<div class="power">
<h3>Datadog</h3>
<p>Observability</p>
</div>
<div class="power">
<h3>Figma</h3>
<p>Design-to-code</p>
</div>
<div class="power">
<h3>Neon</h3>
<p>Serverless Postgres</p>
</div>
<div class="power">
<h3>Supabase</h3>
<p>Backend-as-a-Service</p>
</div>
<div class="power">
<h3>Stripe</h3>
<p>Payments</p>
</div>
<div class="power">
<h3>Netlify</h3>
<p>Edge deployment</p>
</div>
<div class="power">
<h3>Postman</h3>
<p>API testing</p>
</div>
<div class="power">
<h3>AWS IAM</h3>
<p>Policy Autopilot</p>
</div>
</div>

<p class="note"><strong>Each Power includes:</strong> MCP server (external APIs/docs) + steering files (best practices) + hooks (automation)</p>

<p class="note">Browse all Powers: https://github.com/kirodotdev/powers</p>

---

# Kiro Autonomous Agent

<style scoped>
.intro { font-size: 0.55em; color: #545B64; margin-bottom: 15px; }
.features { display: flex; gap: 15px; margin-top: 15px; }
.feature { flex: 1; background: white; padding: 15px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 3px solid #FF9900; }
.feature h3 { margin: 0 0 8px 0; font-size: 0.65em; color: #232F3E; }
.feature p { margin: 0; font-size: 0.48em; color: #545B64; line-height: 1.5; }
.access { margin-top: 15px; background: #FEF3E8; padding: 12px; border-radius: 8px; font-size: 0.5em; text-align: center; }
</style>

<p class="intro">An AI software-development agent that can independently plan, execute, test, and deliver coding tasks with minimal human intervention. Available at <strong>Kiro Web</strong>.</p>

<div class="features">
<div class="feature">
<h3>Parallel Execution</h3>
<p>Run up to 10 tasks concurrently while you focus on other work</p>
</div>
<div class="feature">
<h3>Multi-Repo Support</h3>
<p>Works across multiple repositories, creates PRs automatically</p>
</div>
<div class="feature">
<h3>Persistent Context</h3>
<p>Remembers your patterns and preferences across sessions</p>
</div>
<div class="feature">
<h3>GitHub Integration</h3>
<p>Assign work via "kiro" label or /kiro comment on issues</p>
</div>
</div>

---

# When to Use SDD vs. Vibe Coding

<style scoped>
.compare { display: flex; gap: 20px; margin-top: 15px; }
.col { flex: 1; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
.col h3 { margin: 0 0 12px 0; font-size: 0.8em; }
.col ul { margin: 0; padding-left: 20px; font-size: 0.52em; line-height: 1.6; }
.vibe { border-top: 4px solid #0073BB; }
.sdd { border-top: 4px solid #FF9900; }
.bottom { margin-top: 20px; text-align: center; font-size: 0.6em; background: white; padding: 15px; border-radius: 8px; border-left: 4px solid #FF9900; }
</style>

<div class="compare">
<div class="col vibe">
<h3>Vibe Coding</h3>
<ul>
<li>Quick prototypes and experiments</li>
<li>One-off scripts and utilities</li>
<li>Learning new frameworks</li>
<li>Throwaway code for demos</li>
</ul>
</div>
<div class="col sdd">
<h3>Spec-Driven Development</h3>
<ul>
<li>Features shipping to production</li>
<li>Code that will be maintained for years</li>
<li>Team collaboration required</li>
<li>Compliance or audit requirements</li>
<li>Complex business logic</li>
</ul>
</div>
</div>


---

# Reducing Credit Usage

<style scoped>
.tips { display: flex; gap: 15px; margin-top: 20px; }
.tip { flex: 1; background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.1); padding: 15px; border-radius: 8px; border-top: 3px solid #FF9900; }
.tip h3 { margin: 0 0 8px 0; font-size: 0.7em; color: #232F3E; }
.tip p { margin: 0; font-size: 0.5em; line-height: 1.5; color: #545B64; }
.bottom { text-align: center; margin-top: 25px; font-size: 0.6em; color: #FF9900; font-weight: bold; }
</style>

<div class="tips">
<div class="tip">
<h3>Be Specific</h3>
<p>Detailed steering files and clear specs = correct code first time</p>
</div>
<div class="tip">
<h3>Edit, Don't Regenerate</h3>
<p>Fix typos or small issues manually instead of asking Kiro to rewrite entire files</p>
</div>
<div class="tip">
<h3>Small Tasks</h3>
<p>Atomic tasks give predictable results with fewer retries</p>
</div>
</div>

<p class="bottom">Context upfront = fewer iterations = fewer credits</p>

---

# Recap: Kiro Concepts

- **Spec-Driven Development** — Requirements → Design → Tasks
- **Steering Files** — product.md, tech.md, structure.md
- **Agent Hooks** — Automations on file changes
- **MCP Servers** — External tools and data sources
- **Powers** — Bundled MCP + steering + hooks
- **Autonomous Agent** — Background tasks via kiro.dev or GitHub

---

# Workshop Resources

<div style="font-size: 0.5em;">

**What we'll do:** Update an existing blog application with new features using spec-driven development

**Prerequisites:** Node.js and AWS CLI

**AWS Workshop:**
https://catalog.us-east-1.prod.workshops.aws/join?access-code=b651-0c3a10-c7

**GitHub Repository:**
https://github.com/grbncldr/portbase-kiro-workshop

</div>

---

# Logging into Kiro with SSO

<style scoped>
.steps { display: flex; gap: 12px; margin-top: 10px; }
.step { flex: 1; text-align: center; }
.step img { width: 100%; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.15); }
.step h3 { margin: 10px 0 5px 0; font-size: 0.6em; color: #FF9900; }
.step p { margin: 0; font-size: 0.45em; color: #545B64; line-height: 1.4; }
.config { margin-top: 15px; background: white; padding: 12px 20px; border-radius: 8px; border-left: 4px solid #FF9900; font-size: 0.7em; }
.config code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; }
</style>

<div class="steps">
<div class="step">
<img src="image.png" alt="Step 1">
<h3>Step 1</h3>
<p>Click <strong>"Your organization"</strong></p>
</div>
<div class="step">
<img src="image2.png" alt="Step 2">
<h3>Step 2</h3>
<p>Click <strong>"Sign in via IAM Identity Center instead"</strong></p>
</div>
<div class="step">
<img src="image3.png" alt="Step 3">
<h3>Step 3</h3>
<p>Enter Portbase SSO details and click <strong>Continue</strong></p>
</div>
</div>

<div class="config">
<strong>Portbase SSO Configuration:</strong> Start URL: <code>https://portbase.awsapps.com/start</code> | Region: <code>eu-west-1</code>
</div>

---

# Evaluation

<div style="font-size: 0.55em; text-align: center; margin-top: 30px;">

**Please share your feedback:**
https://www.metricsthatmatter.com/url/u.aspx?C5552312D236867837

</div>
